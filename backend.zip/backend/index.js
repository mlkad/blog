import express from "express";
import fs from "fs";
import multer from "multer";
import cors from "cors";
import mongoose from "mongoose";
import dotenv from "dotenv";
import path from 'path';
import { handleValidationErrors, checkAuth } from "./utils/index.js";

dotenv.config();

import userRoutes from "./routes/users.js";
import postRoutes from "./routes/posts.js";

mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => console.log("DB is ok"))
  .catch((err) => console.log("DB error", err));

const app = express();

const storage = multer.diskStorage({
  destination: (_, __, cb) => {
    if (!fs.existsSync("uploads")) {
      fs.mkdirSync("uploads");
    }
    cb(null, "uploads");
  },
  filename: (_, file, cb) => {
    cb(null, file.originalname);
  },
});

const upload = multer({ storage });

app.use(express.json());
app.use(cors());
app.use("/uploads", express.static("uploads"));

app.use("/auth", userRoutes);
app.use("/posts", postRoutes);

app.post("/upload", checkAuth, upload.single("image"), (req, res) => {
  res.json({
    url: `/uploads/${req.file.originalname}`,
  });
});

app.listen(process.env.PORT || 4405, (err) => {
  if (err) {
    return console.log(err);
  }

  console.log("Server OK");
});

const __dirname = path.resolve();
app.use(express.static(path.join(__dirname, 'frontend', 'build')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'build', 'index.html'));
});
