import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { generateOtp } from '../utils/generateOtp.js';
import { sendOtpEmail } from '../utils/sendOtpEmail.js';

const router = express.Router();

// Регистрация с 2FA
router.post('/register', async (req, res) => {
  try {
    const { email, password } = req.body;
    let user = await User.findOne({ email });
    if (user) return res.status(400).json({ message: 'Email уже зарегистрирован' });

    const otp = generateOtp();
    const hashedPassword = await bcrypt.hash(password, 10);
    user = new User({ email, password: hashedPassword, otp, isVerified: false });
    await user.save();

    await sendOtpEmail(email, otp);
    res.status(200).json({ message: 'OTP отправлен на email' });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// Подтверждение OTP
router.post('/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    const user = await User.findOne({ email });
    if (!user || user.otp !== otp) return res.status(400).json({ message: 'Неверный код' });

    user.isVerified = true;
    user.otp = null;
    await user.save();

    res.status(200).json({ message: 'Аккаунт подтвержден' });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// Вход с завершением предыдущей сессии
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) return res.status(400).json({ message: 'Неверные учетные данные' });

    if (!user.isVerified) return res.status(400).json({ message: 'Подтвердите email' });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    user.token = token;
    await user.save();

    res.status(200).json({ token });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

export default router;
