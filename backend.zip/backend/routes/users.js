import express from 'express';
import jwt from 'jsonwebtoken';
import checkAuth from "../utils/checkAuth.js";
import User from '../models/User.js';

const router = express.Router();
router.use(checkAuth);


// Получить всех пользователей (пример для админа)
router.get('/', async (req, res) => {
  try {
    const users = await User.find({}, '-password -otp -token'); // Исключаем пароли и OTP
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

// Получить информацию о текущем пользователе
router.get("/me", async (req, res) => {
  try {
    const user = await User.findById(req.userId, "-password -otp");
    if (!user) return res.status(404).json({ message: "Пользователь не найден" });

    res.status(200).json(user);
  } catch (err) {
    res.status(500).json({ message: "Ошибка сервера" });
  }
});

// Удалить аккаунт (только сам пользователь)
router.delete('/delete', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ message: 'Нет доступа' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    await User.findByIdAndDelete(decoded.id);

    res.status(200).json({ message: 'Аккаунт удален' });
  } catch (err) {
    res.status(500).json({ message: 'Ошибка сервера' });
  }
});

export default router;
